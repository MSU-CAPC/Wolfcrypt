#define MQX_CPU                 PSP_CPU_MK60DN512Z
