This folder has moved to `IDE/RISCV/SIFIVE-HIFIVE1`.
